<template>
  <el-carousel :interval="4000" type="card" height="500px">
    <el-carousel-item v-for="item in imagebox" :key="item.id">
      <img :src="item.idView" class="image" > 
    </el-carousel-item>
  </el-carousel>
</template>

<script>
  export default{
    name:'zmd',
    data(){
      return {
        imagebox:[{id:0,idView:require('../../assets/zhexian.png')},
        {id:1,idView:require('../../assets/zhuzhuang.png')},
        ]
      }
    }
  }
</script>

<style>
  .el-carousel__item h3 {
    color: #475669;
    font-size: 14px;
    opacity: 0.75;
    line-height: 200px;
    margin: 0;
  }
  
  .el-carousel__item:nth-child(1) {
    background-color: #99a9bf;
  }
  
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
</style>