<template>
    <div>
<el-row>

  <el-col :span="7">
      <div class="block">
    <span class="demonstration">请选择查看时间</span>
    <el-date-picker
      v-model="value2"
      type="datetime"
      placeholder="选择日期时间"
      align="right"
      :picker-options="pickerOptions">
    </el-date-picker>
  </div>
  </el-col>
  <el-col :span="5">
      <el-button type="primary" icon="el-icon-check" circle @click="getTableData()"></el-button>
  </el-col>
</el-row>
<el-row>
  <el-table
    :data="tableData"
    border
    style="width:100%"
    >
    <el-table-column
      prop="name"
      label="姓名"
      width="200">
    </el-table-column>
    <el-table-column
      prop="password"
      label="密码"
      width="200">
    </el-table-column>
    <el-table-column
      prop="identify"
      label="身份"
      width="200">
    </el-table-column>
    <el-table-column
      prop="email"
      label="邮箱"
      width="447">
    </el-table-column>
    <el-table-column
      label="操作"
      width="130">
      <template>
        <el-button type="text" size="small">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
</el-row>

    </div> 
</template>


<script>
 import {message} from '@/api/api'
  export default {
    methods: {
      getTableData(){
        this.$axios.post(`/api/users/message`).then((res)=>
        {this.tableData=res.data;}).catch(function(error){
          console.log(error);
        })
      }
    },

    data() {
      return {
        tableData: [{
          date: '2016-05-02',
          name: '王小虎',
          province: '上海',
          city: '普陀区',
          address: '上海市普陀区金沙江路 1518 弄',
          zip: 200333
        }
         ]
      }
    },
   
  }
</script>

<style>
.el-table-column{
  text-align: 'center'
}
</style>