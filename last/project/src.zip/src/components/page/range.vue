<template>
    <!-- <button @click="getMouseXY($event)">点击获取鼠标坐标</button> -->
    <div id="app">
  <div class="circle" @touchstart="touchstart" @touchmove="touchmove" ></div>
</div>

</template>
     
<script>
     export default{
        methods: {
        // 当鼠标点击时触发，类似onclick事件
            touchstart(e) {
                 console.log('touchstart')
                 // 获取x 坐标
                e.targetTouches[0].clientX 
                // 获取y 坐标
                e.targetTouches[0].clientY
             },
         }
     }
     
</script>


