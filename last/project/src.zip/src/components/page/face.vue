<template>
<el-row>
  <el-col :span="14">
     <img src="http://127.0.0.1:5000/getface_feed">
  </el-col>
</el-row>

     
</template>