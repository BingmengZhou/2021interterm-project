<template>
    <img src="http://127.0.0.1:5000/facedetection_feed">
</template>