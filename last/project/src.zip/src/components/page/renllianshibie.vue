<template>
    <img src="http://127.0.0.1:5000/facereco_feed">
</template>