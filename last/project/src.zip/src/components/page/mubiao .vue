<template>
    <img src="http://127.0.0.1:5000/camshift_feed">
</template>