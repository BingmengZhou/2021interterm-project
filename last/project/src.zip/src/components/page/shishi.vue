<template>
    <img src="http://127.0.0.1:5000/shishi_feed">
</template>