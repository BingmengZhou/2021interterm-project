<template>
    <div class="sidebar">
        <el-menu
            class="sidebar-el-menu"
            :default-active="onRoutes"
            :collapse="collapse"
            background-color="#324157"
            text-color="#bfcbd9"
            active-text-color="#20a0ff"
            unique-opened
            router> 
              <el-menu-item index="1" @click="main()">
                <i class="el-icon-setting"></i>
                <span slot="title">系统首页</span>
            </el-menu-item>
            
            <el-submenu index="2">
                <template slot="title">
                    <i class="el-icon-warning"></i>
                    <span>入侵信息</span>
                </template>
                <el-menu-item-group>
                    <template slot="title"></template>
                        <el-menu-item index="2-1" class="el-icon-s-management" @click="table()" >   查看入侵记录</el-menu-item>
                        <el-menu-item index="2-2"  class="el-icon-data-line" @click="chart()">   入侵统计图表</el-menu-item>
                </el-menu-item-group>
            </el-submenu>   

            <el-submenu index="3">
                <template slot="title">
                    <i class="el-icon-thumb"></i>
                    <span>模式选择</span>
                </template>
                <el-menu-item-group>
                    <template slot="title"></template>
                        <el-menu-item index="2-1" class="el-icon-user-solid" @click="renliantance()">   人脸检测</el-menu-item>
                        <el-menu-item index="2-2" class="el-icon-user" @click="renlianshibie()">   人脸识别</el-menu-item>
                        <el-menu-item index="2-3" class="el-icon-s-custom" @click="mubiao()">   目标追踪</el-menu-item>
                </el-menu-item-group>
            </el-submenu>   


            <el-menu-item index="4" @click="shishi()"> 
                <i class="el-icon-video-camera"></i>
                <span slot="title">查看实时监控</span>
            </el-menu-item>


        </el-menu>
    </div>
</template>

<script>
import bus from '../common/bus';
export default {
    data(){
        return{
            collapse: false,
        };
    },
         created() {
        // 通过 Event Bus 进行组件间通信，来折叠侧边栏
         bus.$on('collapse', msg => {
            this.collapse = msg;
            bus.$emit('collapse-content', msg);
         });
    },
    methods: {
      main(){
          this.$router.push('/main');
      },
      table(){
          this.$router.push('/table');
      },
      chart(){
          this.$router.push('/chart');
      },
      member(){
          this.$router.push('/member');
      },
      shishi(){
          this.$router.push('/shishi');
      },
      renliantance(){
          this.$router.push('/renliantance');
      },
      renlianshibie(){
          this.$router.push('/renlianshibie');
      },
      mubiao(){
          this.$router.push('/mubiao');
      },


      handleOpen(key, keyPath) {
        console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
      }
    }

}
</script>


<style scoped>
.sidebar {
    display: block;
    position: absolute;
    left: 0;
    top: 60px;
    bottom: 0;
    overflow-y: scroll;
}
.sidebar::-webkit-scrollbar {
    width: 0;
}
.sidebar-el-menu:not(.el-menu--collapse) {
    width: 250px;
}
.sidebar > ul {
    height: 100%;
}
</style>