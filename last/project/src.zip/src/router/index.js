import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: '/login',
      component: () => import('../components/login.vue'),   
      meta: { title: '登录'}
    },
    {
      path: '/chome',
      name:'chome',
      component: () => import('../components/common/CHome.vue'),
      meta: { title: '管理员系统'},
      redirect:'/main1',
      children: [
        {
          // 实时视频
          path: '/shishi1',
          component: () => import('../components/page/shishi.vue'),
          meta: { title: '实时视频' }
        },
        {
          // 人脸探测
          path: '/renliantance1',
          component: () => import('../components/page/renliantance.vue'),
          meta: { title: '人脸探测' }
        },
        {
          // 人脸识别
          path: '/renlianshibie1',
          component: () => import('../components/page/renllianshibie.vue'),
          meta: { title: '人脸识别' }
        },
        {
          // 目标追踪
          path: '/mubiao1',
          component: () => import('../components/page/mubiao .vue'),
          meta: { title: '目标追踪' }
        },
        {
          // 警戒区域
          path: '/jingjie1',
          component: () => import('../components/page/jingjie.vue'),
          meta: { title: '警戒区域' }
        },
        {
          // 入侵信息表格
          path: '/main1',
          component: () => import('../components/page/Main.vue'),
          meta: { title: '入侵信息' }
        },
        {
          // 入侵信息表格
          path: '/table1',
          component: () => import('../components/page/Table.vue'),
          meta: { title: '查看入侵记录' }
        },
        {
           // 图
           path: '/chart1',
           component: () => import('../components/page/Chart.vue'),
           meta: { title: '入侵统计图表' }
         },
         {
          // 用户信息
          path: '/member1',
          component: () => import('../components/page/Member.vue'),
          meta: { title: '用户信息管理' }
        },
        {
          // 行人检测
          path: '/road',
          component: () => import('../components/page/xingrentance.vue'),
          meta: { title: '行人检测' }
        },
        {
          // 人脸录入
          path: '/face',
          component: () => import('../components/page/face.vue'),
          meta: { title: '人脸录入' }
        },
        
      ]
    },{
      path: '/uhome',
      name:'uhome',
      component: () => import('../components/common/UHome.vue'),
      meta: { title: '用户系统'},
      redirect:'/main',
      children: [
        {
          // 实时视频
          path: '/shishi',
          component: () => import('../components/page/shishi.vue'),
          meta: { title: '实时视频' }
        },
        {
          // 人脸探测
          path: '/renliantance',
          component: () => import('../components/page/renliantance.vue'),
          meta: { title: '人脸探测' }
        },
        {
          // 人脸识别
          path: '/renlianshibie',
          component: () => import('../components/page/renllianshibie.vue'),
          meta: { title: '人脸识别' }
        },
        {
          // 目标追踪
          path: '/mubiao',
          component: () => import('../components/page/mubiao .vue'),
          meta: { title: '目标追踪' }
        },
        {
          // 主页
          path: '/main',
          component: () => import('../components/page/Main.vue'),
          meta: { title: '系统主页' }
        },
        {
          // 入侵信息表格
          path: '/table',
          component: () => import('../components/page/Table.vue'),
          meta: { title: '查看入侵记录' }
        },
        {
           // 图
           path: '/chart',
           component: () => import('../components/page/Chart.vue'),
           meta: { title: '入侵统计图表' }
         },
      ]
    },
  ]
})