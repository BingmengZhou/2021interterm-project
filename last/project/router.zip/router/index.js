import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: '/login',
      component: () => import('../components/login.vue'),   
      meta: { title: '登录'}
    },
    {
      path: '/chome',
      name:'chome',
      component: () => import('../components/common/CHome.vue'),
      meta: { title: '管理员系统'},
      redirect:'/main1',
      children: [
        {
          // 入侵信息表格
          path: '/main1',
          component: () => import('../components/page/Main.vue'),
          meta: { title: '系统主页' }
        },
        {
          // 入侵信息表格
          path: '/table1',
          component: () => import('../components/page/Table.vue'),
          meta: { title: '查看入侵记录' }
        },
        {
           // 图
           path: '/chart1',
           component: () => import('../components/page/Chart.vue'),
           meta: { title: '入侵统计图表' }
         },
         {
          // 用户信息
          path: '/member1',
          component: () => import('../components/page/Member.vue'),
          meta: { title: '用户信息管理' }
        },
      ]
    },{
      path: '/uhome',
      name:'uhome',
      component: () => import('../components/common/UHome.vue'),
      meta: { title: '用户系统'},
      redirect:'/main',
      children: [
        {
          // 入侵信息表格
          path: '/main',
          component: () => import('../components/page/Main.vue'),
          meta: { title: '系统主页' }
        },
        {
          // 入侵信息表格
          path: '/table',
          component: () => import('../components/page/Table.vue'),
          meta: { title: '查看入侵记录' }
        },
        {
           // 图
           path: '/chart',
           component: () => import('../components/page/Chart.vue'),
           meta: { title: '入侵统计图表' }
         },
      ]
    },
  ]
})