import axios from 'axios';    // 导入axios

let host = 'http://127.0.0.1:5000/api';

// 登录
export const login = params => { return axios.post(`${host}/user/login`, params)};

// 注册
export const register = params => { return axios.post(`${host}/user/register`, params)};
