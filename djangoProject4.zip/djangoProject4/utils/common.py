# _aother_:
# _date_ :
# utils/common.py
result = {
     "message": None,
     "success": False,
     "details": None
 }