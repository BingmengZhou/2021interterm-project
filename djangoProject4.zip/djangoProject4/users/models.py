from django.db import models

# Create your models here.
#users/models.py
from django.db import models

from utils.base_models import BaseModel


class Users(BaseModel):
    id = models.AutoField(primary_key=True, verbose_name='id主键')
    username = models.CharField(max_length=50, unique=True, verbose_name='用户名')
    password = models.CharField(max_length=50, verbose_name='密码')
    email = models.EmailField(max_length=50, verbose_name='邮箱')
    phone = models.CharField(max_length=20, verbose_name='手机号')
    date = models.CharField(max_length=20, verbose_name='生日')
    rename = models.CharField(max_length=20, verbose_name='姓名')
    sex = models.CharField(max_length=20, verbose_name='性别')
    juri = models.CharField(max_length=20, verbose_name='权限')

    def __str__(self):
        return self.username

    class Meta:
        db_table = 'show'
        verbose_name = '用户数据'
        verbose_name_plural = verbose_name