import axios from 'axios';    // 导入axios

let host = 'http://172.27.190.205:8000/api';

// 登录
export const login = params => { return axios.post(`${host}/user/login`, params)};

// 注册
export const register = params => { return axios.post(`${host}/user/register`, params)};

